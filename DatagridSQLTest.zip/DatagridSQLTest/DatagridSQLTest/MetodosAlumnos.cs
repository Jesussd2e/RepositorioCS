﻿using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.Cmp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatagridSQLTest
{
    class MetodosAlumnos
    {
        //Metodo mostrar alumnos.

        public void MostrarAlumnos(DataGridView tablaAlumnos)
        {
            try
            {
                Cconexion ObjetoConexion = new Cconexion();
                string query = "select * from alumnos";
                tablaAlumnos.DataSource = null;
                MySqlDataAdapter adapter = new MySqlDataAdapter(
                    query, ObjetoConexion.EstablecerConexion());

                DataTable dt = new DataTable();
                adapter.Fill(dt);
                tablaAlumnos.DataSource = dt;
                ObjetoConexion.CerrarConexion();
            }
            catch (Exception e)
            {
                MessageBox.Show("Error al intentar conectar a la base de datos..." + e.ToString());
            }

        }
        // Metodo para guardar alumnos.
        public void GuardarAlumnos(TextBox Nombres, TextBox Apellidos)
        {
            try
            {
                Cconexion objetoConexion = new Cconexion();
                if (Nombres.Text != "" && Apellidos.Text != "")
                { //si existe algo en el textbox se ejecuta el proceso guardar -->.
                    string query = "insert into alumnos(Nombres,Apellidos)" +
                        "values('" + Nombres.Text + "','" + Apellidos.Text + "');";
                    MySqlCommand MyCommand = new MySqlCommand(query, objetoConexion.EstablecerConexion());
                    MySqlDataReader reader = MyCommand.ExecuteReader();
                    MessageBox.Show("Guardado correctamente...");
                    //Metodo para recorrer lista.
                    while (reader.Read())
                    {

                    }
                    objetoConexion.CerrarConexion();
                    //Termino del proceso guardar.
                }//Llave de cierre del if.
                else
                {
                    MessageBox.Show("Acomplete los espacios vacios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }


            catch (Exception e)
            {
                MessageBox.Show("No se han logrado guardar los datos..." + e.ToString());
            }

        }
        //Metodo seleccionar alumnos.
        public void seleccionarAlumnos(DataGridView tablaAlumnos, TextBox id, TextBox Nombres, TextBox Apellidos)
        {
            try
            {
                id.Text = tablaAlumnos.CurrentRow.Cells[0].Value.ToString();
                Nombres.Text = tablaAlumnos.CurrentRow.Cells[1].Value.ToString();
                Apellidos.Text = tablaAlumnos.CurrentRow.Cells[2].Value.ToString();
            }
            catch (Exception e)
            {
                MessageBox.Show("No se logro seleccionar" + e.ToString());
            }

        }
        //Metodo modificar.
        public void ModificarAlumnos(TextBox id, TextBox nombre, TextBox apellidos)
        {
            try
            {
                Cconexion objetoConexion = new Cconexion();
                String query = "update alumnos set nombres='" + nombre.Text + "',apellidos='" +
                    apellidos.Text + "'where id='" + id.Text + "';";
                MySqlCommand MyCommand = new MySqlCommand(query, objetoConexion.EstablecerConexion());
                MySqlDataReader Reader = MyCommand.ExecuteReader();
                MessageBox.Show("Registro modificado correctamente");
                while (Reader.Read())
                {
                }
                objetoConexion.CerrarConexion();
            }
            catch (Exception e)
            {
                MessageBox.Show("Error en la modificacion" + e.ToString());
            }
        }
        //Metodo eliminar alumnos.
        public void EliminarAlumnos(TextBox id)
        {
            try
            {
                Cconexion objetoConexion = new Cconexion();
                string query = "delete from alumnos where id='" + id.Text + "';";
                MySqlCommand myCommand = new MySqlCommand(query,objetoConexion.EstablecerConexion());
                MySqlDataReader Reader = myCommand.ExecuteReader();
                MessageBox.Show("Registro eliminado correctamente");
                while (Reader.Read())
                {
                }
                objetoConexion.CerrarConexion();
            }
            catch (Exception e)
            {
                MessageBox.Show("Error al borrar los registros" + e.ToString());
            }
        }
    }
}