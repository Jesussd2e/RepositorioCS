﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatagridSQLTest
{
    class Cconexion
    {
        MySqlConnection conex = new MySqlConnection();

        //Creamos atributos.

        static String servidor = "localhost";
        static String bd = "escuela";
        static String usuario = "root";
        static String password = "password";
        static String puerto = "3306";

        //Cadena de conexión.

        string CadenaConexion = "server= " + servidor + ";" + "port= " + puerto + ";" +
            "user id= " + usuario + ";" + "password= " + password + ";" +
            "database= " + bd + ";";

        //Metodo concectar a base de datos.
        public MySqlConnection EstablecerConexion()
        {
            try
            {
                conex.ConnectionString = CadenaConexion;
                conex.Open();
            }
            catch (MySqlException e)
            {
                MessageBox.Show("ERROR AL CONECTAR A LA BD." + e.ToString());
            }
            return conex;
        }
        //2do metodo cerrar conexion.

        public void CerrarConexion()
        {
            conex.Close();
        }


    }
}
