﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatagridSQLTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            MetodosAlumnos objAlumnos = new MetodosAlumnos();
            objAlumnos.MostrarAlumnos(dataGridView1);
        }
        private void limpiar()
        {
            txtb_nombre.Text = "";
            txtb_apellido.Text = "";
            txtb_nombre.Focus();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_agregar_Click(object sender, EventArgs e)
        {
            MetodosAlumnos objetoAlumnos = new MetodosAlumnos();
            objetoAlumnos.GuardarAlumnos(txtb_nombre, txtb_apellido);
            objetoAlumnos.MostrarAlumnos(dataGridView1);
            limpiar();
        }

        private void btn_editar_Click(object sender, EventArgs e)
        {
            MetodosAlumnos objetoAlumnos = new MetodosAlumnos();
            objetoAlumnos.ModificarAlumnos(txtb_id, txtb_nombre, txtb_apellido);
            objetoAlumnos.MostrarAlumnos(dataGridView1);
            limpiar();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            MetodosAlumnos objetoAlumnos = new MetodosAlumnos();
            objetoAlumnos.seleccionarAlumnos(dataGridView1, txtb_id, txtb_nombre, txtb_apellido);
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            MetodosAlumnos ObjetoAlumnos = new MetodosAlumnos();
            ObjetoAlumnos.EliminarAlumnos(txtb_id);
            ObjetoAlumnos.MostrarAlumnos(dataGridView1);
        }
    }
}